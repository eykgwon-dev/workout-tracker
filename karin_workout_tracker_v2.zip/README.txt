Workout Tracker v2

Swimming plan:
- 10 laps Freestyle
- 10 laps Breaststroke
- 10 laps Backstroke
- 4 cool-down laps
Total: 34 laps = 850 m in a 25 m pool.
